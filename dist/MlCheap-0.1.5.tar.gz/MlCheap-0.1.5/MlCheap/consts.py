TEXT_TAGGING_TYPE = 'text-tagging'
